# Recipes

> [!note]
> These recipe examples may have not been maintained with library updates, and are provided as-is for reference purposes.

> [!warning]
> These are recipe examples are intended for specific hardware usage.
